| Type | Severity | VulnerabilityID | Title | Description | InstalledVersion | FixedVersion |
|:--|:--|:--|:--|:--|:--|:--|
